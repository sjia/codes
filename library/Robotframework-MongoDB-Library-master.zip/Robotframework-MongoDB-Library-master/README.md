Robotframework-MongoDB-Library
==============================

A library for interacting with MongoDB from RobotFramework.

Uses pymongo.

License
-------
See LICENSE file for updated license information

Install
-------
You can install by pulling down source and executing the following:

'''
sudo python setup.py install
'''

