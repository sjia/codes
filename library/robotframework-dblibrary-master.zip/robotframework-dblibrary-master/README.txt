The Robot Framework Database Library is a library which provides common functionality for testing database contents. Please see the wiki on github for more information and the provided keywords.
