/*
 * Copyright 2008-2011 Nokia Siemens Networks Oyj
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package org.robotframework.remoteapplications.server;

import org.robotframework.javalib.library.RobotJavaLibrary;
import org.robotframework.javalib.util.ArrayUtil;
import org.robotframework.javalib.util.KeywordNameNormalizer;
import org.robotframework.remoteapplications.common.KeywordExecutionResult;

public class CloseableRobotRmiService implements RobotRmiService {
    private final RobotRmiService wrappedService;

    public CloseableRobotRmiService(RobotRmiService wrappedService) {
        this.wrappedService = wrappedService;
    }

    public String[] getKeywordNames() {
        return ArrayUtil.add(wrappedService.getKeywordNames(), "systemexit");
    }

    public KeywordExecutionResult runKeyword(String keywordName, Object[] keywordArguments) {
        if (isSystemExit(keywordName)) {
            System.exit(0);
        }
        return wrappedService.runKeyword(keywordName, keywordArguments);
    }

    public void setLibrary(RobotJavaLibrary library) {
        wrappedService.setLibrary(library);
    }

    private boolean isSystemExit(String keywordName) {
        return new KeywordNameNormalizer().normalize(keywordName).equals("systemexit");
    }

    public boolean ping() {
       return wrappedService.ping();
    }
}
