package org.robotframework.remoteapplications.mocks;

public class SomeClass {
    public static String[] args;
    public static void main(String[] args) {
        SomeClass.args = args;
    }
}
