== RemoteApplications Demo ==

This is a simple demonstration using RemoteApplications library.

To run the demo:

python run.py robot-tests/standalone_application.txt

For instructions on running the WebStart demo see:
https://github.com/robotframework/RemoteApplications/wiki/Demo
