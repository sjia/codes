INSERT INTO person VALUES(1,'Franz Allan','See');
INSERT INTO person VALUES(2,'Jerry','Schneider');
