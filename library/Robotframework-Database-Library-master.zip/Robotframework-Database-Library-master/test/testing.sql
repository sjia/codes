# Simple sql file for testing with RobotFramework-DatabaseLibrary (Python)
SELECT COUNT(*) FROM data_formats;
