#encoding: utf-8
unic_text = u'ÄÖÅåöä €€ scandic toimii kivasti'
